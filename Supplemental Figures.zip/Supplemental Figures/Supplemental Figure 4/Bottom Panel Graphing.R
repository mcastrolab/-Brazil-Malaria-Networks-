setwd("/Supplementary Figure 4")

d1 <- read.csv(file="GCMR_API_data_04to22_NOLVC.csv")
d2 <- read.csv(file="RILA_map_data.csv")

library(dplyr)
install.packages("ggplot2")
library(ggplot2)

names(d1)
names(d2)

d1b <- d1 %>%
  group_by(mun,year) %>%
  summarise(cases_total=sum(cases),
            pop=mean(population))

d3 <- merge(d1b,d2,all=T,by.x=c("mun","year"),by.y=c("MUN_NOTI","year"))
d3 <- d3[d3$year>2003,]
summary(d3)
d3 <- d3[!is.na(d3$pop),]
d3[is.na(d3)] <- 0
summary(d3)

d3$API <- (d3$cases_total/d3$pop)*1000


#Tables by year and mun
#API
d3_api <- subset(d3, select=c(
  "mun",
  "year.y",
  "API"
))

summary(d3_api)

library(tidyr)

d3_api$year <- as.factor(d3_api$year)
d3_api <- na.omit(d3_api)
d3_api2 <- spread(d3_api, year, API)

d3_api2[is.na(d3_api2)] <- 0
d3_api2$`2004` <- as.numeric(d3_api2$`2004`)
d3_api2$`2005` <- as.numeric(d3_api2$`2005`)
d3_api2$`2006` <- as.numeric(d3_api2$`2006`)
d3_api2$`2007` <- as.numeric(d3_api2$`2007`)
d3_api2$`2008` <- as.numeric(d3_api2$`2008`)
d3_api2$`2009` <- as.numeric(d3_api2$`2009`)
d3_api2$`2010` <- as.numeric(d3_api2$`2010`)
d3_api2$`2011` <- as.numeric(d3_api2$`2011`)
d3_api2$`2012` <- as.numeric(d3_api2$`2012`)
d3_api2$`2013` <- as.numeric(d3_api2$`2013`)
d3_api2$`2014` <- as.numeric(d3_api2$`2014`)
d3_api2$`2015` <- as.numeric(d3_api2$`2015`)
d3_api2$`2016` <- as.numeric(d3_api2$`2016`)
d3_api2$`2017` <- as.numeric(d3_api2$`2017`)
d3_api2$`2018` <- as.numeric(d3_api2$`2018`)
d3_api2$`2019` <- as.numeric(d3_api2$`2019`)
d3_api2$`2020` <- as.numeric(d3_api2$`2020`)

d3_api2$mun2 <- with(d3_api2,paste("x",mun))

d3_api2$mun2 <- as.factor(d3_api2$mun2)

d3_api2[d3_api2==0] <- 0
d3_api2[d3_api2>50] <- 3
d3_api2[d3_api2>10] <- 2
d3_api2[d3_api2==3] <- "HIGH"
d3_api2[d3_api2==2] <- "MED"
d3_api2[d3_api2==0] <- "NONE"

#Imported

d3_imp <- subset(d3, select=c(
  "mun",
  "year",
  "imported"
))

summary(d3_imp)

library(tidyr)

d3_imp$year <- as.factor(d3_imp$year)
d3_imp <- na.omit(d3_imp)
d3_imp2 <- spread(d3_imp, year, imported)

d3_imp2[is.na(d3_imp2)] <- 0

#Exported
d3$exported <- d3$cases_out_btw+d3$cases_out_within

d3_exp <- subset(d3, select=c(
  "mun",
  "year",
  "exported"
))

summary(d3_exp)

library(tidyr)

d3_exp$year <- as.factor(d3_exp$year)
d3_exp <- na.omit(d3_exp)
d3_exp2 <- spread(d3_exp, year, exported)

d3_exp2[is.na(d3_exp2)] <- 0

#Autochthonous
d3_local <- subset(d3, select=c(
  "mun",
  "year",
  "local"
))

summary(d3_local)

library(tidyr)

d3_local$year <- as.factor(d3_local$year)
d3_local <- na.omit(d3_local)
d3_local2 <- spread(d3_local, year, local)

d3_local2[is.na(d3_local2)] <- 0

#########################
d3$uf <- substr(d3$mun,1,2)

d4 <- na.omit(d3)

ufs <- unique(d3$uf)

d4$yrgrp <- 4
d4$yrgrp[d4$year.y<2019] <- 3
d4$yrgrp[d4$year.y<2015] <- 2
d4$yrgrp[d4$year.y<2009] <- 1

for (i in ufs) {
  
p <- ggplot(d4[d4$uf==i,], aes(x=perc_imp, y=log(API))) +
  geom_point() +
  facet_wrap(~yrgrp) +
  labs(title=i,x="Percent of Cases Imported")

print(p)

}

d4$yrgrp <- 3
d4$yrgrp[d4$year<2017] <- 2
d4$yrgrp[d4$year<2010] <- 1

ufs <- unique(d4$uf)
yrgrp <- c(1,2,3)

d4$logapi <- log(d4$API)
d4$logratio <- log(d4$ratio_imp_loc)

d4[is.na(d4) | d4 == "-Inf"] <- NA 

summary(d4)

library(scales) # to access break formatting functions
install.packages("ggpubr",dependencies=T)
library(ggpubr)
library(ggplot2)



library(RColorBrewer)
d4 <- d3
d4$uf <- substr(d4$mun,1,2)

d4$yrgrp <- 3
d4$yrgrp[d4$year<2017] <- 2
d4$yrgrp[d4$year<2010] <- 1
d4$uf[!(d4$uf%in%c(11:17,21,51))] <- "Other"

p <- ggplot(d4[d4$imported>0,], aes(x=RILA, y=API,col=as.factor(uf)),group=as.factor(uf)) +
  geom_point(alpha=0) +
  geom_smooth(method = "lm", se = T,aes(fill=as.factor(uf))) +
  scale_x_log10(breaks = trans_breaks("log10", function(x) 10^x),
                labels = trans_format("log10", math_format())) +
  scale_y_log10(breaks = trans_breaks("log10", function(x) 10^x),
                labels = trans_format("log10", math_format())) +
  annotation_logticks() +
  stat_regline_equation(aes(label = ..rr.label..)) +
  facet_wrap(~as.factor(yrgrp),scales="fixed") +
  theme_classic() +
  scale_color_manual(values=c("#D16103",  "#FFDB6D", "#C4961A", "#F4EDCA",
                              "#52854C","#C07272", "#C3D7A4", "#4E84C4", "#293352","#808080")) +
scale_fill_manual(values=c("#D16103",  "#FFDB6D", "#C4961A", "#F4EDCA",
                            "#52854C","#C07272", "#C3D7A4", "#4E84C4", "#293352","#808080")) +
    theme(strip.background = element_blank(),
        strip.text.x = element_blank()) +
  labs(x="Imported Cases : Autochthonous Cases",y="Annual Parasitic Index of Municipality") +
  scale_alpha(guide = 'none')
p

p2 <- ggplot(d4, aes(x=ratio_imp_loc, y=API)) +
  geom_point(alpha=0) +
  geom_smooth(method = "lm", se = T) +
  scale_x_log10(breaks = trans_breaks("log10", function(x) 10^x),
                labels = trans_format("log10", math_format())) +
  scale_y_log10(breaks = trans_breaks("log10", function(x) 10^x),
                labels = trans_format("log10", math_format())) +
  annotation_logticks() +
  # stat_regline_equation() +
  facet_wrap(~yrgrp,ncol=4,nrow=1,scales="fixed") +
  theme_classic() +
  theme(strip.background = element_blank(),
        strip.text.x = element_blank()) +
  labs(x="Imported Cases : Autochthonous Cases",y="Annual Parasitic Index of Municipality") +
  scale_alpha(guide = 'none')
p2

d4$uf_name <- NULL
d4$uf_name[d4$uf=="11"] <- "RO"
d4$uf_name[d4$uf=="12"] <- "AC"
d4$uf_name[d4$uf=="13"] <- "AM"
d4$uf_name[d4$uf=="14"] <- "RR"
d4$uf_name[d4$uf=="15"] <- "PA"
d4$uf_name[d4$uf=="16"] <- "AP"
d4$uf_name[d4$uf=="17"] <- "TO"
d4$uf_name[d4$uf=="21"] <- "MA"
d4$uf_name[d4$uf=="51"] <- "MT"

m <- lm(log(API)~log(ratio_imp_loc)+uf_name+as.factor(yrgrp),data=d4[d4$imported>0,])
summary(m)

install.packages("sjPlot")
install.packages("sjmisc")
install.packages("sjlabelled")

library(sjPlot)
library(sjmisc)
library(sjlabelled)

tab_model(m)

# 
# p11 <- ggplot(d4[d4$uf==11&d4$imported>0,], aes(x=ratio_imp_loc, y=API)) +
#   geom_point(aes(alpha=0.05)) +
#   geom_smooth(method = "lm", se = T, color = "dark red") +
#   scale_x_log10(breaks = trans_breaks("log10", function(x) 10^x),
#                 labels = trans_format("log10", math_format(10^.x))) +
#   scale_y_log10(breaks = trans_breaks("log10", function(x) 10^x),
#                 labels = trans_format("log10", math_format(10^.x))) +
#   annotation_logticks() +
#   # stat_regline_equation(aes(label = ..rr.label..)) +
#   facet_wrap(~yrgrp,ncol=4,nrow=1,scales="free") +
#   theme_classic() +
#   theme(strip.background = element_blank(),
#         strip.text.x = element_blank()) +
#   labs(x=NULL,y=NULL) +
#   scale_alpha(guide = 'none')
# p11
# 
# p12 <- ggplot(d4[d4$uf==12&d4$imported>0,], aes(x=ratio_imp_loc, y=API)) +
#   geom_point(aes(alpha=0.05)) +
#   geom_smooth(method = "lm", se = T, color = "dark red") +
#   scale_x_log10(breaks = trans_breaks("log10", function(x) 10^x),
#                 labels = trans_format("log10", math_format(10^.x))) +
#   scale_y_log10(breaks = trans_breaks("log10", function(x) 10^x),
#                 labels = trans_format("log10", math_format(10^.x))) +
#   annotation_logticks() +
#   stat_regline_equation(aes(label = ..rr.label..)) +
#   facet_wrap(~yrgrp,ncol=4,nrow=1,scales="free") +
#   theme_classic() +
#   theme(strip.background = element_blank(),
#         strip.text.x = element_blank()) +
#   labs(x=NULL,y=NULL) +
#   scale_alpha(guide = 'none')
# p12
# 
# p13 <- ggplot(d4[d4$uf==13&d4$imported>0,], aes(x=ratio_imp_loc, y=API)) +
#   geom_point(aes(alpha=0.05)) +
#   geom_smooth(method = "lm", se = T, color = "dark red") +
#   scale_x_log10(breaks = trans_breaks("log10", function(x) 10^x),
#                 labels = trans_format("log10", math_format(10^.x))) +
#   scale_y_log10(breaks = trans_breaks("log10", function(x) 10^x),
#                 labels = trans_format("log10", math_format(10^.x))) +
#   annotation_logticks() +
#   stat_regline_equation(aes(label = ..rr.label..)) +
#   facet_wrap(~yrgrp,ncol=4,nrow=1,scales="free") +
#   theme_classic() +
#   theme(strip.background = element_blank(),
#         strip.text.x = element_blank()) +
#   labs(x=NULL,y=NULL) +
#   scale_alpha(guide = 'none')
# p13
# 
# p14 <- ggplot(d4[d4$uf==14&d4$imported>0,], aes(x=ratio_imp_loc, y=API)) +
#   geom_point(aes(alpha=0.05)) +
#   geom_smooth(method = "lm", se = T, color = "dark red") +
#   scale_x_log10(breaks = trans_breaks("log10", function(x) 10^x),
#                 labels = trans_format("log10", math_format(10^.x))) +
#   scale_y_log10(breaks = trans_breaks("log10", function(x) 10^x),
#                 labels = trans_format("log10", math_format(10^.x))) +
#   annotation_logticks() +
#   stat_regline_equation(aes(label = ..rr.label..)) +
#   facet_wrap(~yrgrp,ncol=4,nrow=1,scales="free") +
#   theme_classic() +
#   theme(strip.background = element_blank(),
#         strip.text.x = element_blank()) +
#   labs(x=NULL,y=NULL) +
#   scale_alpha(guide = 'none')
# p14
# 
# p15 <- ggplot(d4[d4$uf==15&d4$imported>0,], aes(x=ratio_imp_loc, y=API)) +
#   geom_point(aes(alpha=0.05)) +
#   geom_smooth(method = "lm", se = T, color = "dark red") +
#   scale_x_log10(breaks = trans_breaks("log10", function(x) 10^x),
#                 labels = trans_format("log10", math_format(10^.x))) +
#   scale_y_log10(breaks = trans_breaks("log10", function(x) 10^x),
#                 labels = trans_format("log10", math_format(10^.x))) +
#   annotation_logticks() +
#   stat_regline_equation(aes(label = ..rr.label..)) +
#   facet_wrap(~yrgrp,ncol=4,nrow=1,scales="free") +
#   theme_classic() +
#   theme(strip.background = element_blank(),
#         strip.text.x = element_blank()) +
#   labs(x=NULL,y=NULL) +
#   scale_alpha(guide = 'none')
# p15
# 
# p16 <- ggplot(d4[d4$uf==16&d4$imported>0,], aes(x=ratio_imp_loc, y=API)) +
#   geom_point(aes(alpha=0.05)) +
#   geom_smooth(method = "lm", se = T, color = "dark red") +
#   scale_x_log10(breaks = trans_breaks("log10", function(x) 10^x),
#                 labels = trans_format("log10", math_format(10^.x))) +
#   scale_y_log10(breaks = trans_breaks("log10", function(x) 10^x),
#                 labels = trans_format("log10", math_format(10^.x))) +
#   annotation_logticks() +
#   stat_regline_equation(aes(label = ..rr.label..)) +
#   facet_wrap(~yrgrp,ncol=4,nrow=1,scales="free") +
#   theme_classic() +
#   theme(strip.background = element_blank(),
#         strip.text.x = element_blank()) +
#   labs(x=NULL,y=NULL) +
#   scale_alpha(guide = 'none')
# p16
# 
# p17 <- ggplot(d4[d4$uf==17&d4$imported>0,], aes(x=ratio_imp_loc, y=API)) +
#   geom_point(aes(alpha=0.05)) +
#   geom_smooth(method = "lm", se = T, color = "dark red") +
#   scale_x_log10(breaks = trans_breaks("log10", function(x) 10^x),
#                 labels = trans_format("log10", math_format(10^.x))) +
#   scale_y_log10(breaks = trans_breaks("log10", function(x) 10^x),
#                 labels = trans_format("log10", math_format(10^.x))) +
#   annotation_logticks() +
#   stat_regline_equation(aes(label = ..rr.label..)) +
#   facet_wrap(~yrgrp,ncol=4,nrow=1,scales="free") +
#   theme_classic() +
#   theme(strip.background = element_blank(),
#         strip.text.x = element_blank()) +
#   labs(x=NULL,y=NULL) +
#   scale_alpha(guide = 'none')
# p17
# 
# 
# p21 <- ggplot(d4[d4$uf==21&d4$imported>0,], aes(x=ratio_imp_loc, y=API)) +
#   geom_point(aes(alpha=0.05)) +
#   geom_smooth(method = "lm", se = T, color = "dark red") +
#   scale_x_log10(breaks = trans_breaks("log10", function(x) 10^x),
#                 labels = trans_format("log10", math_format(10^.x))) +
#   scale_y_log10(breaks = trans_breaks("log10", function(x) 10^x),
#                 labels = trans_format("log10", math_format(10^.x))) +
#   annotation_logticks() +
#   stat_regline_equation(aes(label = ..rr.label..)) +
#   facet_wrap(~yrgrp,ncol=4,nrow=1,scales="free") +
#   theme_classic() +
#   theme(strip.background = element_blank(),
#         strip.text.x = element_blank()) +
#   labs(x=NULL,y=NULL) +
#   scale_alpha(guide = 'none')
# p21
# 
# p51 <- ggplot(d4[d4$uf==51&d4$imported>0,], aes(x=ratio_imp_loc, y=API)) +
#   geom_point(aes(alpha=0.05)) +
#   geom_smooth(method = "lm", se = T, color = "dark red") +
#   scale_x_log10(breaks = trans_breaks("log10", function(x) 10^x),
#                 labels = trans_format("log10", math_format(10^.x))) +
#   scale_y_log10(breaks = trans_breaks("log10", function(x) 10^x),
#                 labels = trans_format("log10", math_format(10^.x))) +
#   annotation_logticks() +
#   stat_regline_equation(aes(label = ..rr.label..)) +
#   facet_wrap(~yrgrp,ncol=4,nrow=1,scales="free") +
#   theme_classic() +
#   theme(strip.background = element_blank(),
#         strip.text.x = element_blank()) +
#   labs(x=NULL,y=NULL) +
#   scale_alpha(guide = 'none')
# p51
# 
# ggarrange(p11,p12,p13,p14,p15,p16,p17,p21,p51, 
#           labels = NULL,
#           ncol = 1, nrow = 9)