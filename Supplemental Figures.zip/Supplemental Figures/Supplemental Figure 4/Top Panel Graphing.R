library(ggplot2)
library(lubridate)
library(zoo)
library(dplyr)

setwd("/Supplementary Figure 4")
gmr <- read.csv(file="GMR_data.csv")
sosi <- read.csv("source and sink cluster data for maps.csv")

d <- rbind(gmr,sosi)

cases <- read.csv("GCMR_API_data_04to22_NOLVC.csv")

cases_grp <- cases %>%
  group_by(mun,year) %>%
  summarise(case_total=sum(cases),
            pop=mean(population))

cases_grp$year_grp <- 3
cases_grp$year_grp[cases_grp$year<2017] <- 2
cases_grp$year_grp[cases_grp$year<2010] <- 1

cases_grp$API <- (cases_grp$case_total/cases_grp$pop)*1000

m2 <- merge(cases_grp,d,by=c("mun","year_grp"),all=T)
m2 <- m2[!is.na(m2$type),]

m_yr1 <- m2[m2$yr_grp==1,]
m_yr2 <- m2[m2$yr_grp==2,]
m_yr3 <- m2[m2$yr_grp==3,]

ggplot(NULL,aes(x=metric)) + 
  geom_boxplot(data=m_yr1,aes(x=yr_grp, y=log(API),fill=factor(type))) +
  geom_boxplot(data=m_yr2,aes(x=yr_grp, y=log(API),fill=factor(type))) +
  geom_boxplot(data=m_yr3,aes(x=yr_grp, y=log(API),fill=factor(type))) +
  geom_segment(aes(y=log(median(na.omit(m2$API[m2$yr_grp==1]))),
                   yend=log(median(na.omit(m2$API[m2$yr_grp==1]))),x=.6,xend=1.4), linetype="solid", 
               color = "black", size=1.5) +
  geom_segment(aes(y=log(quantile(na.omit(m2$API[m2$yr_grp==1]),.25)),
                   yend=log(quantile(na.omit(m2$API[m2$yr_grp==1]),.25)),x=.6,xend=1.4),linetype="dashed", 
               color = "black", size=1) +
  geom_segment(aes(y=log(quantile(na.omit(m2$API[m2$yr_grp==1]),.75)),
                   yend=log(quantile(na.omit(m2$API[m2$yr_grp==1]),.75)),x=.6,xend=1.4),linetype="dashed", 
               color = "black", size=1) +
  
  geom_segment(aes(y=log(median(na.omit(m2$API[m2$yr_grp==2]))),
                   yend=log(median(na.omit(m2$API[m2$yr_grp==2]))),x=1.6,xend=2.4), linetype="solid", 
               color = "black", size=1.5) +
  geom_segment(aes(y=log(quantile(na.omit(m2$API[m2$yr_grp==2]),.25)),
                   yend=log(quantile(na.omit(m2$API[m2$yr_grp==2]),.25)),x=1.6,xend=2.4),linetype="dashed", 
               color = "black", size=1) +
  geom_segment(aes(y=log(quantile(na.omit(m2$API[m2$yr_grp==2]),.75)),
                   yend=log(quantile(na.omit(m2$API[m2$yr_grp==2]),.75)),x=1.6,xend=2.4),linetype="dashed", 
               color = "black", size=1) +
  
  geom_segment(aes(y=log(median(na.omit(m2$API[m2$yr_grp==3]))),
                   yend=log(median(na.omit(m2$API[m2$yr_grp==3]))),x=2.6,xend=3.4), linetype="solid", 
               color = "black", size=1.5) +
  geom_segment(aes(y=log(quantile(na.omit(m2$API[m2$yr_grp==3]),.25)),
                   yend=log(quantile(na.omit(m2$API[m2$yr_grp==3]),.25)),x=2.6,xend=3.4),linetype="dashed", 
               color = "black", size=1) +
  geom_segment(aes(y=log(quantile(na.omit(m2$API[m2$yr_grp==3]),.75)),
                   yend=log(quantile(na.omit(m2$API[m2$yr_grp==3]),.75)),x=2.6,xend=3.4),linetype="dashed", 
               color = "black", size=1) +
    theme_classic() +
  coord_cartesian(ylim=c(-6,8))

exp(-4)
exp(0)
exp(4)
exp(8)

# 
# m_yr_grp1 <- merge(d[d$yrgrp==1,],m,by="code")
# m_yr_grp1$API <- (m_yr_grp1$total/m_yr_grp1$pop)*1000
# 
# m_yr_grp2 <- merge(d[d$yrgrp==2,],m,by="code")
# m_yr_grp2$API <- (m_yr_grp2$total/m_yr_grp2$pop)*1000
# 
# m_yr_grp3 <- merge(d[d$yrgrp==3,],m,by="code")
# m_yr_grp3$API <- (m_yr_grp3$total/m_yr_grp3$pop)*1000
# 
# m_yr_grp4 <- merge(d[d$yrgrp==4,],m,by="code")
# m_yr_grp4$API <- (m_yr_grp4$total/m_yr_grp4$pop)*1000
# 
# 
# ggplot(NULL,aes(x=metric)) + 
#   geom_boxplot(data=m_yr_grp1,aes(x=yrgrp, y=log(API),fill=factor(metric))) +
#   geom_boxplot(data=m_yr_grp2,aes(x=yrgrp, y=log(API),fill=factor(metric))) +
#   geom_boxplot(data=m_yr_grp3,aes(x=yrgrp, y=log(API),fill=factor(metric))) +
#   geom_boxplot(data=m_yr_grp4,aes(x=yrgrp, y=log(API),fill=factor(metric))) +
#   geom_segment(aes(y=log(median(na.omit(m$API_total[m$yr_grp==1]))),
#                    yend=log(median(na.omit(m$API_total[m$yr_grp==1]))),x=.6,xend=1.4), linetype="solid", 
#                color = "black", size=1.5) +
#   geom_segment(aes(y=log(quantile(na.omit(m$API_total[m$yr_grp==1]),.25)),
#                    yend=log(quantile(na.omit(m$API_total[m$yr_grp==1]),.25)),x=.6,xend=1.4),linetype="dashed", 
#                color = "black", size=1) +
#   geom_segment(aes(y=log(quantile(na.omit(m$API_total[m$yr_grp==1]),.75)),
#                    yend=log(quantile(na.omit(m$API_total[m$yr_grp==1]),.75)),x=.6,xend=1.4),linetype="dashed", 
#                color = "black", size=1) +
#   
#   geom_segment(aes(y=log(median(na.omit(m$API_total[m$yr_grp==2]))),
#                    yend=log(median(na.omit(m$API_total[m$yr_grp==2]))),x=1.6,xend=2.4), linetype="solid", 
#                color = "black", size=1.5) +
#   geom_segment(aes(y=log(quantile(na.omit(m$API_total[m$yr_grp==2]),.25)),
#                    yend=log(quantile(na.omit(m$API_total[m$yr_grp==2]),.25)),x=1.6,xend=2.4),linetype="dashed", 
#                color = "black", size=1) +
#   geom_segment(aes(y=log(quantile(na.omit(m$API_total[m$yr_grp==2]),.75)),
#                    yend=log(quantile(na.omit(m$API_total[m$yr_grp==2]),.75)),x=1.6,xend=2.4),linetype="dashed", 
#                color = "black", size=1) +
#   
#   geom_segment(aes(y=log(median(na.omit(m$API_total[m$yr_grp==3]))),
#                    yend=log(median(na.omit(m$API_total[m$yr_grp==3]))),x=2.6,xend=3.4), linetype="solid", 
#                color = "black", size=1.5) +
#   geom_segment(aes(y=log(quantile(na.omit(m$API_total[m$yr_grp==3]),.25)),
#                    yend=log(quantile(na.omit(m$API_total[m$yr_grp==3]),.25)),x=2.6,xend=3.4),linetype="dashed", 
#                color = "black", size=1) +
#   geom_segment(aes(y=log(quantile(na.omit(m$API_total[m$yr_grp==3]),.75)),
#                    yend=log(quantile(na.omit(m$API_total[m$yr_grp==3]),.75)),x=2.6,xend=3.4),linetype="dashed", 
#                color = "black", size=1) +
#   
#   geom_segment(aes(y=log(median(na.omit(m$API_total[m$yr_grp==4]))),
#                    yend=log(median(na.omit(m$API_total[m$yr_grp==4]))),x=3.6,xend=4.4), linetype="solid", 
#                color = "black", size=1.5) +
#   geom_segment(aes(y=log(quantile(na.omit(m$API_total[m$yr_grp==4]),.25)),
#                    yend=log(quantile(na.omit(m$API_total[m$yr_grp==4]),.25)),x=3.6,xend=4.4),linetype="dashed", 
#                color = "black", size=1) +
#   geom_segment(aes(y=log(quantile(na.omit(m$API_total[m$yr_grp==4]),.75)),
#                    yend=log(quantile(na.omit(m$API_total[m$yr_grp==4]),.75)),x=3.6,xend=4.4),linetype="dashed", 
#                color = "black", size=1) +
#   theme_classic() +
#   coord_cartesian(ylim=c(-6,6))
