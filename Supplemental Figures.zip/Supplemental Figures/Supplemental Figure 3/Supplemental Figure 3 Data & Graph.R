library(dplyr)
library(tidyverse)
library(ggplot2)

setwd("/Supplementary Figure 4")
dat <- read.csv(file="GCMR_API_data_04to22_NOLVC.csv")
dat <- na.omit(dat)
str(dat)
mean(dat$sink_between)
sd(dat$sink_between)
summary(dat)

dat2 <- dat %>%
  group_by(mun,year) %>%
  summarise(sib_CV=mean(sink_between)/sd(sink_between),
            siw_CV=mean(sink_within)/sd(sink_within),
            sob_CV=mean(source_between)/sd(source_between),
            sow_CV=mean(source_within)/sd(source_within))

colnames(dat2) <- c("mun","year","Sink Between","Sink Within","Source Between","Source Within")
dat3 <- gather(dat2, type, CV, "Sink Between":"Source Within", factor_key=TRUE) 
ggplot(na.omit(dat3), aes(x=type, y=CV)) + 
  geom_boxplot() + 
  scale_color_grey() +
  theme_classic() +
  labs(x="Type", y = "Coefficient of Variation")
