library(dplyr)
library(lubridate)
library(ggplot2)
library(zoo)
install.packages("forecast")
library(forecast)
library(tidyr)
library(data.table)

d1_full <- fread(file="/Supplemental Figure 2/Seasonality Data.csv")
names(d1_full)

tsdata3 <- d1_full
colnames(tsdata3) <- c("v1","year","UF","month","cases","imported","within","between","local")
tsdata3$year_month <- as.yearmon(paste(tsdata3$year,tsdata3$month, sep="-"))

# #Seasonality Plots Within & Between & Local -- Whole Amazon
# Within_ts <- ts(data=tsdata2$within)
# trend_Within = ma(Within_ts, order = 12, centre = T)
# detrend_Within = Within_ts / trend_Within
# m_Within = t(matrix(data = detrend_Within, nrow = 12))
# seasonal_Within = colMeans(m_Within, na.rm = T) 
# 
# Between_ts <- ts(data=tsdata2$between)
# trend_Between = ma(Between_ts, order = 12, centre = T)
# detrend_Between = Between_ts / trend_Between
# m_Between = t(matrix(data = detrend_Between, nrow = 12))
# seasonal_Between = colMeans(m_Between, na.rm = T) 
# 
# Local_ts <- ts(data=tsdata2$local)
# trend_Local = ma(Local_ts, order = 12, centre = T)
# detrend_Local = Local_ts / trend_Local
# m_Local = t(matrix(data = detrend_Local, nrow = 12))
# seasonal_Local = colMeans(m_Local, na.rm = T) 
# 
# imported_ts <- ts(data=tsdata2$imported)
# trend_imported = ma(imported_ts, order = 12, centre = T)
# detrend_imported = imported_ts / trend_imported
# m_imported = t(matrix(data = detrend_imported, nrow = 12))
# seasonal_imported = colMeans(m_imported, na.rm = T) 
# 
# plot(as.ts(rep(seasonal_Between,18)),ylab="Seasonal Between",ylim=c(0.75,1.3))
# lines(as.ts(rep(seasonal_Within,18)),ylab="Seasonal Within",col="blue")
# plot(as.ts(rep(seasonal_Local,18)),ylab="Seasonal Local",col="red",ylim=c(0.75,1.3))
# lines(as.ts(rep(seasonal_imported,18)),ylab="Seasonal Imported",col="black")

#By State
tsdata3$UF[!(tsdata3$UF%in%c(11:17,21,51))] <- "Other"

ufs1 <- c("Other")

for (i in ufs1) {
  Within_ts <- ts(data=tsdata3$within[tsdata3$UF==i])
  trend_Within = ma(Within_ts, order = 12, centre = T)
  detrend_Within = Within_ts / trend_Within
  m_Within = t(matrix(data = detrend_Within, nrow = 12))
  seasonal_Within = colMeans(m_Within, na.rm = T) 
  
  Between_ts <- ts(data=tsdata3$between[tsdata3$UF==i])
  trend_Between = ma(Between_ts, order = 12, centre = T)
  detrend_Between = Between_ts / trend_Between
  m_Between = t(matrix(data = detrend_Between, nrow = 12))
  seasonal_Between = colMeans(m_Between, na.rm = T) 
  
  Local_ts <- ts(data=tsdata3$local[tsdata3$UF==i])
  trend_Local = ma(Local_ts, order = 12, centre = T)
  detrend_Local = Local_ts / trend_Local
  m_Local = t(matrix(data = detrend_Local, nrow = 12))
  seasonal_Local = colMeans(m_Local, na.rm = T) 
  
  imported_ts <- ts(data=tsdata3$imported[tsdata3$UF==i])
  trend_imported = ma(imported_ts, order = 12, centre = T)
  detrend_imported = imported_ts / trend_imported
  m_imported = t(matrix(data = detrend_imported, nrow = 12))
  seasonal_imported = colMeans(m_imported, na.rm = T) 
  
  plot(as.ts(rep(seasonal_Local,18)),ylab="Seasonal Local",lwd=1.5,ylim=c(0.5,1.15))
  lines(as.ts(rep(seasonal_Within,18)),col="blue",lwd=1.5)
  lines(as.ts(rep(seasonal_Between,18)),col="red",lwd=1.5)
  lines(as.ts(rep(seasonal_imported,18)),col="dark green",lwd=1.5)
  
}
