library(dplyr)

setwd("Supplementary Table 6")
dat <- read.csv(file="GCMR_API_data_04to22_NOLVC.csv")

dat2 <- dat %>%
  group_by(year,mun) %>%
  summarise(population=mean(population),
            sib=sum(sink_between),
            siw=sum(sink_within),
            sob=sum(source_between),
            sow=sum(source_within),
            cases=sum(cases))

dat2$GCMR <- ((dat2$siw+dat2$sib+dat2$sow+dat2$sob)/dat2$population)*1000
dat2$API <- (dat2$cases/dat2$population)*1000

dat3 <- dat2 %>%
  group_by(mun) %>%
  summarise(mean_GCMR = mean(GCMR),
            mean_API = mean(API))

write.csv(dat3,file="Supplemental Table 6 data for formatting.csv")
