library(dplyr)

setwd("Supplemental Table 5")
dat <- read.csv(file="GCMR_API_data_04to22_NOLVC.csv")

dat2 <- dat %>%
  group_by(year,mun) %>%
  summarise(population=mean(population),
            sib=sum(sink_between),
            siw=sum(sink_within),
            sob=sum(source_between),
            sow=sum(source_within),
            cases=sum(cases))

dat2$GCMR <- ((dat2$siw+dat2$sib+dat2$sow+dat2$sob)/dat2$population)*1000
dat2$API <- (dat2$cases/dat2$population)*1000

write.csv(dat2,file="Annual_GCMR_API.csv")

m2 <- cor.test(dat2$API[dat2$year==2004],dat2$GCMR[dat2$year==2004])
m3 <- cor.test(dat2$API[dat2$year==2005],dat2$GCMR[dat2$year==2005])
m4 <- cor.test(dat2$API[dat2$year==2006],dat2$GCMR[dat2$year==2006])
m5 <- cor.test(dat2$API[dat2$year==2007],dat2$GCMR[dat2$year==2007])
m6 <- cor.test(dat2$API[dat2$year==2008],dat2$GCMR[dat2$year==2008])
m7 <- cor.test(dat2$API[dat2$year==2009],dat2$GCMR[dat2$year==2009])
m8 <- cor.test(dat2$API[dat2$year==2010],dat2$GCMR[dat2$year==2010])
m9 <- cor.test(dat2$API[dat2$year==2011],dat2$GCMR[dat2$year==2011])
m10 <- cor.test(dat2$API[dat2$year==2012],dat2$GCMR[dat2$year==2012])
m11 <- cor.test(dat2$API[dat2$year==2013],dat2$GCMR[dat2$year==2013])
m12 <- cor.test(dat2$API[dat2$year==2014],dat2$GCMR[dat2$year==2014])
m13 <- cor.test(dat2$API[dat2$year==2015],dat2$GCMR[dat2$year==2015])
m14 <- cor.test(dat2$API[dat2$year==2016],dat2$GCMR[dat2$year==2016])
m15 <- cor.test(dat2$API[dat2$year==2017],dat2$GCMR[dat2$year==2017])
m16 <- cor.test(dat2$API[dat2$year==2018],dat2$GCMR[dat2$year==2018])
m17 <- cor.test(dat2$API[dat2$year==2019],dat2$GCMR[dat2$year==2019])
m18 <- cor.test(dat2$API[dat2$year==2020],dat2$GCMR[dat2$year==2020])
m19 <- cor.test(dat2$API[dat2$year==2021],dat2$GCMR[dat2$year==2021])
m20 <- cor.test(dat2$API[dat2$year==2022],dat2$GCMR[dat2$year==2022])

coef <- c(m2$estimate,
  m3$estimate,
  m4$estimate,
  m5$estimate,
  m6$estimate,
  m7$estimate,
  m8$estimate,
  m9$estimate,
  m10$estimate,
  m11$estimate,
  m12$estimate,
  m13$estimate,
  m14$estimate,
  m15$estimate,
  m16$estimate,
  m17$estimate,
  m18$estimate,
  m19$estimate,
  m20$estimate)

confint <- c(m2$conf.int,
             m3$conf.int,
             m4$conf.int,
             m5$conf.int,
             m6$conf.int,
             m7$conf.int,
             m8$conf.int,
             m9$conf.int,
             m10$conf.int,
             m11$conf.int,
             m12$conf.int,
             m13$conf.int,
             m14$conf.int,
             m15$conf.int,
             m16$conf.int,
             m17$conf.int,
             m18$conf.int,
             m19$conf.int,
             m20$conf.int)

pvalue <- c(m2$p.value,
             m3$p.value,
             m4$p.value,
             m5$p.value,
             m6$p.value,
             m7$p.value,
             m8$p.value,
             m9$p.value,
             m10$p.value,
             m11$p.value,
             m12$p.value,
             m13$p.value,
             m14$p.value,
             m15$p.value,
             m16$p.value,
             m17$p.value,
             m18$p.value,
             m19$p.value,
             m20$p.value)

pearsons <- cbind(coef,confint[1:19],confint[20:38],pvalue)

write.csv(pearsons,file="Supplemental_Table_5_pearson_coefficients_by_year_SINAN_UPDATED.csv")

cor.test(dat2$API,dat2$GCMR)
